package com.example.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.jackandphantom.androidlikebutton.AndroidLikeButton;

public class complaints extends AppCompatActivity {

    AndroidLikeButton like;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complaints);
        like=findViewById(R.id.likebtn);

        like.setOnLikeEventListener(new AndroidLikeButton.OnLikeEventListener() {
            @Override
            public void onLikeClicked(AndroidLikeButton androidLikeButton) {
                Toast.makeText(complaints.this,"Mark as read",Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onUnlikeClicked(AndroidLikeButton androidLikeButton) {


            }
        });
    }
}